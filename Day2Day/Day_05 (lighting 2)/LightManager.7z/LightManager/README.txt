This is just a suggestion or example of the sort of thing you might want to make, and it is incomplete (mainly just the trivial "helper" functions/methods).

Feel free to use this, if you want, but if you don't like it, then please make something yourself, to suit your own tastes. 

Michael 